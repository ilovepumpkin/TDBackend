package testdash.data.er.ttt;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.htmlcleaner.HtmlCleaner;
import org.htmlcleaner.TagNode;

import testdash.data.er.ERStatusProvider;
import testdash.model.ERStatusRecord;
import testdash.model.TeamContext;
import testdash.util.TestDashUtil;

public class FVTERStatusProvider implements ERStatusProvider {

	public ERStatusRecord getERStatusRecord(TeamContext tc) {
		String tttViewURL = tc.getProperty("tttViewURL");
		String phaseName = tc.getProperty("phaseName");
		String htmlContent = TestDashUtil.getHTMLContentWithoutAuth(tttViewURL);
		return parseContent(htmlContent, phaseName);
	}

	private ERStatusRecord parseContent(String htmlContent, String phaseName) {
		ERStatusRecord esr = null;
		// create an instance of HtmlCleaner
		HtmlCleaner cleaner = new HtmlCleaner();

		try {
			TagNode node = cleaner.clean(htmlContent);
			List tables = node.getElementListByName("table", true);
			TagNode dataTable = (TagNode) tables.get(1);
			List trs = dataTable.getElementListByName("tr", true);
			for (Iterator iter = trs.iterator(); iter.hasNext();) {
				TagNode tr = (TagNode) iter.next();
				if (tr.getText().indexOf(phaseName) != -1) {
					List tds = tr.getElementListByName("td", false);
					long unattempted = Long.parseLong(((TagNode) tds.get(1))
							.getText().toString());
					long attempted = Long.parseLong(((TagNode) tds.get(2))
							.getText().toString());
					long blocked = Long.parseLong(((TagNode) tds.get(3))
							.getText().toString());
					long failed = Long.parseLong(((TagNode) tds.get(4))
							.getText().toString());
					long complete = Long.parseLong(((TagNode) tds.get(5))
							.getText().toString());
					long permfailed = Long.parseLong(((TagNode) tds.get(6))
							.getText().toString());
					long deferred = Long.parseLong(((TagNode) tds.get(7))
							.getText().toString());

					esr = new ERStatusRecord(attempted, blocked, complete,
							deferred, failed, permfailed, unattempted);
					break;
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return esr;
	}

}
