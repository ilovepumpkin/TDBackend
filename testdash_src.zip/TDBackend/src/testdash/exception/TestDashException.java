package testdash.exception;

public class TestDashException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8684403163747212105L;

	public TestDashException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TestDashException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public TestDashException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public TestDashException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
