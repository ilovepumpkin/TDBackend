package testdash.oper;

import java.util.List;
import java.util.Map;

public interface BugGrouper {
	public Map group(List bugList);
}
